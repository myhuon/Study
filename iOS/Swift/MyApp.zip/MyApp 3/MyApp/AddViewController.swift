
import UIKit
import MobileCoreServices

protocol AddDelegate: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    func didAddDone(_ controller: AddViewController, message: String)
}

class AddViewController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    @IBOutlet var dpPicker: UIDatePicker!
    @IBOutlet var tfTitle: UITextField!
    @IBOutlet var tfDetail: UITextField!
    @IBOutlet var imageView: UIImageView!
    
    var delegate: AddViewController?
    
    var iconFileName: String = ""
    let imagePicker: UIImagePickerController! = UIImagePickerController()
    var captureImage: UIImage!
    var flagImageSave = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // DatePicker 에 현재 시간 설정
        let date = NSDate()
        dpPicker.setDate(date as Date, animated: true)
    }
    
    @IBAction func btnCaptureImageFromCamera(_ sender: UIButton) {
        // 외부의 앱을 사용할 시에는 성공,실패의 경우를 생각해야한다. (카메라 앱은 외부 앱)
        if (UIImagePickerController.isSourceTypeAvailable(.camera)) {   // . 붙은 값은 enumeration 값임을 나타내는 것이다.
            flagImageSave = true
            
            imagePicker.delegate = self
            imagePicker.sourceType = .camera
            imagePicker.mediaTypes = ["public.image"]   // 개인 저장소가 아닌 공동의 저장소의 이미지 타입으로 지정
            imagePicker.allowsEditing = false   // 사진 편집기능 가능하도록 할 것인지 설정
            
            present(imagePicker, animated: true, completion: nil)
        } else {
            myAlert("Camera inaccessable", message: "Application cannot access the camera.")
        }
    }
    
    @IBAction func btnLoadingImageFromLibrary(_ sender: UIButton) {
        if (UIImagePickerController.isSourceTypeAvailable(.photoLibrary)) {
            flagImageSave = false
            
            imagePicker.delegate = self
            imagePicker.sourceType = .photoLibrary
            imagePicker.mediaTypes = ["public.image"]
            imagePicker.allowsEditing = true
            
            present(imagePicker, animated: true, completion: nil)
        } else {
            myAlert("Photo album inaccessable", message: "Application cannot access the photo album.")
        }
    }
    
    @IBAction func btnSave(_ sender: UIButton) {
        // 뷰에 입력한 값을 사용하여 DB에 추가
        let pickerTime = Int32(dpPicker.date.timeIntervalSince1970)
        manager.insert(title: tfTitle.text ?? "title", date: pickerTime, detail: tfDetail.text!, icon: iconFileName)
        
        _ = navigationController?.popViewController(animated: true)
    }
    
    // imagePickerController 응답 처리
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let mediaType = info[UIImagePickerController.InfoKey.mediaType] as! NSString
        
        if mediaType.isEqual(to: "public.image" as String) {
            captureImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
            
            if flagImageSave {  // 이미지 저장 작업
                UIImageWriteToSavedPhotosAlbum(captureImage, self, nil, nil)
            }
            
            imageView.image = captureImage
            iconFileName = (info[UIImagePickerController.InfoKey.imageURL] as! NSURL).absoluteString ?? "cart.png"
        }
        
        // 카메라 닫기
        self.dismiss(animated: true, completion: nil)
    }
    
    // imagePickerController가 취소 되었을 때 카메라 닫기
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func myAlert (_ title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        let action = UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil)
        alert.addAction(action)
        self.present(alert, animated: true, completion: nil)
    }
    
}

